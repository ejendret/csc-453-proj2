#ifndef SCHEDULERSH
#define SCHEDULERSH

#include "lwp.h"
extern scheduler AlwaysZero;
extern scheduler ChangeOnSIGTSTP;
extern scheduler ChooseHighestColor;
extern scheduler ChooseLowestColor;
#endif
